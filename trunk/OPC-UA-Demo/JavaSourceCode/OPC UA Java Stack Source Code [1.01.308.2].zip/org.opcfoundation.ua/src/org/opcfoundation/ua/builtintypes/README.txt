See package.html for details about classes of builtin types.
