/* ========================================================================
 * Copyright (c) 2005-2010 The OPC Foundation, Inc. All rights reserved.
 *
 * OPC Reciprocal Community License ("RCL") Version 1.00
 * 
 * Unless explicitly acquired and licensed from Licensor under another 
 * license, the contents of this file are subject to the Reciprocal 
 * Community License ("RCL") Version 1.00, or subsequent versions as 
 * allowed by the RCL, and You may not copy or use this file in either 
 * source code or executable form, except in compliance with the terms and 
 * conditions of the RCL.
 * 
 * All software distributed under the RCL is provided strictly on an 
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
 * AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT 
 * LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
 * PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the RCL for specific 
 * language governing rights and limitations under the RCL.
 *
 * The complete license agreement can be found here:
 * http://opcfoundation.org/License/RCL/1.00/
 * ======================================================================*/

package org.opcfoundation.ua.builtintypes;

import java.util.Arrays;

import org.opcfoundation.ua.encoding.DecodingException;
import org.opcfoundation.ua.encoding.EncodeType;
import org.opcfoundation.ua.encoding.EncoderContext;
import org.opcfoundation.ua.encoding.EncoderMode;
import org.opcfoundation.ua.encoding.EncodingException;
import org.opcfoundation.ua.encoding.IEncodeable;
import org.opcfoundation.ua.encoding.binary.BinaryDecoder;
import org.opcfoundation.ua.encoding.binary.BinaryEncoder;
import org.opcfoundation.ua.encoding.binary.EncoderCalc;
import org.opcfoundation.ua.encoding.binary.IEncodeableSerializer;
import org.opcfoundation.ua.utils.StackUtils;



/**
 * Extension object contains a {@link Structure} which is either 
 * XML or binary encoded. 
 *  
 * @author Toni Kalajainen (toni.kalajainen@vtt.fi)
 */
public class ExtensionObject {

	/**
	 * Create extension object by encoding an encodeable to a binary format 
	 * using the default serializer.
	 * 
	 * @param encodeable encodeable
	 * @return binary encoded encodeable
	 * @throws EncodingException on encoding problem
	 */
	public static ExtensionObject binaryEncode(Structure encodeable) 
	throws EncodingException
	{
		return binaryEncode( encodeable, StackUtils.getDefaultSerializer() );
	}
	
	/**
	 * Create extension object by encoding an encodeable to a binary format
	 * 
	 * @param encodeable encodeable
	 * @param serializer serializer
	 * @return binary encoded encodeable
	 * @throws EncodingException on encoding problem
	 */
	public static ExtensionObject binaryEncode(Structure encodeable, IEncodeableSerializer serializer)
	throws EncodingException
	{
		EncoderContext ctx = new EncoderContext();
		ctx.setEncodeableSerializer(serializer);			
		EncoderCalc calc = new EncoderCalc();
		calc.setEncoderContext(ctx);
		serializer.calcEncodeable(encodeable.getClass(), encodeable, calc);
		byte[] data = new byte[calc.getLength()];
		BinaryEncoder enc = new BinaryEncoder(data);
		enc.setEncoderMode(EncoderMode.NonStrict);
		enc.setEncoderContext(ctx);
		enc.putEncodeable(null, encodeable);
		return new ExtensionObject(encodeable.getBinaryEncodeId(), data);
	}
	
	/**
	 * Create extension object by encoding an encodeable to xml format using
	 * the default serializer
	 * 
	 * @param encodeable encodeable
	 * @return xml encoded encodeable
	 * @throws EncodingException on encoding problem
	 */
	public static ExtensionObject xmlEncode(Structure encodeable)
	throws EncodingException
	{
		throw new Error("Unimplemented");
	}	
	
	/**
	 * Create extension object by encoding an encodeable to xml format
	 * 
	 * @param encodeable encodeable
	 * @param serializer serializer
	 * @return xml encoded encodeable
	 * @throws EncodingException on encoding problem
	 */
	public static ExtensionObject xmlEncode(Structure encodeable, IEncodeableSerializer serializer)
	throws EncodingException
	{
		throw new Error("Unimplemented");
	}		
	
	Object object;
	NodeId typeId; // NodeId of a DataType
	Integer hash;
	EncodeType encodeType;

	public ExtensionObject(NodeId typeId) {
		if (typeId==null)
			throw new IllegalArgumentException("typeId argument must not be null");
		this.typeId = typeId;
	}
	
	public ExtensionObject(NodeId typeId, byte[] object) {
		if (typeId==null)
			throw new IllegalArgumentException("typeId argument must not be null");
		if (object==null)
			throw new IllegalArgumentException("object argument must not be null");
		this.typeId = typeId;
		this.object = object;
		this.encodeType = EncodeType.Binary;
	}

	public ExtensionObject(NodeId typeId, XmlElement object) {
		if (typeId==null)
			throw new IllegalArgumentException("typeId argument must not be null");
		if (object==null){
			//throw new IllegalArgumentException("object argument must not be null");
			this.object = new XmlElement("");
		} else {
			this.object = object;
		}
		this.typeId = typeId;
//		this.object = object;
		this.encodeType = EncodeType.Xml;
		
//		if (typeId==null)
//			throw new IllegalArgumentException("typeId argument must not be null");
//		if (object==null)
//			throw new IllegalArgumentException("object argument must not be null");
//		this.typeId = typeId;
//		this.object = object;
//		this.encodeType = EncodeType.Xml;
	}
	
	public EncodeType getEncodeType() {
		return encodeType;
	}
	
	public Object getObject() {
		return object;
	}

	public NodeId getTypeId() {
		return typeId;
	}
	
	/**
	 * Decode the extension object 
	 * 
	 * @param serializer serializer to use
	 * @param <T>
	 * @return decoded object
	 * @throws DecodingException
	 */
	@SuppressWarnings("unchecked")
	public <T extends IEncodeable> T decode(IEncodeableSerializer serializer) 
	throws DecodingException {
		if (object==null)
		{
			Class<? extends IEncodeable> clazz = serializer.getClass(typeId);
			try {
				return (T) clazz.newInstance();
			} catch (InstantiationException e) {
				// Unexpected
				throw new DecodingException(e);
			} catch (IllegalAccessException e) {
				// Unexpected
				throw new DecodingException(e);
			}
		}
		
		if (object instanceof XmlElement) 
		{
			throw new DecodingException("Xml decoding is not implemented");
		}

		if (object instanceof byte[])
		{
			Class<? extends IEncodeable> clazz = serializer.getClass(typeId);
			EncoderContext ctx = new EncoderContext();
			ctx.setEncodeableSerializer(serializer);
			BinaryDecoder dec = new BinaryDecoder((byte[])object);
			dec.setEncoderContext(ctx);
			return (T) serializer.getEncodeable(clazz, dec);
		}

		throw new Error("unexpected");
	}
	
	/**
	 * Attempts to decode the extension object using the default serializer of the stack.
	 * 
	 * @param <T>
	 * @return decoded object
	 * @throws DecodingException
	 */
	@SuppressWarnings("unchecked")
	public <T extends IEncodeable> T decode() 
	throws DecodingException {
		return (T) decode(StackUtils.getDefaultSerializer());
	}

	@Override
	public synchronized int hashCode() {
		if (hash==null) {
			if (object!=null && object instanceof byte[])
				hash = typeId.hashCode() + 13 * Arrays.hashCode((byte[])object); 
			else if (object!=null && object instanceof XmlElement)
				hash = typeId.hashCode() + 13 * ((XmlElement)object).hashCode();
			else 
				hash = typeId.hashCode();
		}
		return hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ExtensionObject))
			return false;
		ExtensionObject other = (ExtensionObject) obj;
		if (!other.typeId.equals(typeId)) return false;
		
		if (object==null) {
			return other.object==null;
		}
		
		if (object instanceof byte[]) {
			if (!(other.object instanceof byte[])) return false;
			return Arrays.equals((byte[])other.object, (byte[])object);
		}
		
		if (object instanceof XmlElement) {
			if (!(other.object instanceof XmlElement)) return false;
			return ((XmlElement)other.object).equals((XmlElement)object);
		}
		return false;
	}
	
}
