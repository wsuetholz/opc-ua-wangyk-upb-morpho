December 2010

Export file for package 'org.globalplatform' is generated with
 AID: 0xA0:0x00:0x00:0x01:051:0x00
 Version: 1.5
 Backward Compatibility: Version 1.4
